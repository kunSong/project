package org.songkun.service;

import org.songkun.pojo.Items;
import org.springframework.data.elasticsearch.core.aggregation.AggregatedPage;

public interface ESService {

    AggregatedPage<Items> searchES(String keyword, String sort, Integer start, Integer pageSize);
}
