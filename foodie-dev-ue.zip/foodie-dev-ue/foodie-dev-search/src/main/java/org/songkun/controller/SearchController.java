package org.songkun.controller;


import org.apache.commons.lang3.StringUtils;
import org.songkun.pojo.Items;
import org.songkun.service.ESService;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.JsonUtils;
import org.songkun.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.aggregation.AggregatedPage;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/items")
public class SearchController {

    @Autowired
    private ESService esService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @GetMapping("/hello")
    public String helloworld() {
        return "Hello world";
    }

    @GetMapping("/search")
    public IMOOCJSONResult search(@RequestParam String keywords,
                                  @RequestParam String sort,
                                  @RequestParam Integer page,
                                  @RequestParam Integer pageSize) {
        if (StringUtils.isBlank(keywords)) {
            return IMOOCJSONResult.errorMsg("keyword is empty");
        }
        if (page == null) {
            page = 0;
        }
        if (pageSize == null) {
            pageSize = 10;
        }
        page--;

        PagedGridResult pagedGridResult = null;

        String key = keywords + ":" + sort + ":" + page + ":" + pageSize;

        if (redisTemplate.hasKey(key)){
            String result = redisTemplate.opsForValue().get(key);
            pagedGridResult = JsonUtils.jsonToPojo(result, PagedGridResult.class);
        }

        AggregatedPage<Items> items = esService.searchES(keywords, sort, page, pageSize);

        pagedGridResult = setPagedGridResult(items);

        redisTemplate.opsForValue().set(key, JsonUtils.objectToJson(pagedGridResult), 60, TimeUnit.SECONDS);

        return IMOOCJSONResult.ok(pagedGridResult);
    }

    public PagedGridResult setPagedGridResult(AggregatedPage<Items> items) {
        PagedGridResult pagedGridResult = new PagedGridResult();
        pagedGridResult.setTotal(items.getTotalPages());
        pagedGridResult.setPage(items.getPageable().getPageNumber() + 1);
        pagedGridResult.setRecords(items.getTotalElements());
        pagedGridResult.setRows(items.getContent());
        return pagedGridResult;
    }
}
