package org.songkun.service.impl;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.songkun.pojo.Items;
import org.songkun.service.ESService;
import org.songkun.utils.JsonUtils;
import org.songkun.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.SearchResultMapper;
import org.springframework.data.elasticsearch.core.aggregation.AggregatedPage;
import org.springframework.data.elasticsearch.core.aggregation.impl.AggregatedPageImpl;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class ESServiceImpl implements ESService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public AggregatedPage<Items> searchES(String keyword, String sort, Integer start, Integer pageSize) {

        Pageable pageable = PageRequest.of(start, pageSize);

        String queryField = "itemName";
        String highlightField = "itemName";
        String sortField ="itemName.keyword";

        System.out.println(keyword);
        System.out.println(start + " " + pageSize);

        switch (sort) {
            case "c":
                sortField = "sellCounts";
                break;
            case "p":
                sortField = "price";
                break;
                default:
        }

        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.matchQuery(queryField, keyword))
                .withHighlightFields(new HighlightBuilder.Field(highlightField))
                .withPageable(pageable)
                .withSort(SortBuilders.fieldSort(sortField).order(SortOrder.DESC))
                .build();

        AggregatedPage<Items> items = elasticsearchTemplate.queryForPage(searchQuery, Items.class, new SearchResultMapper() {
            @Override
            public <T> AggregatedPage<T> mapResults(SearchResponse response, Class<T> clazz, Pageable pageable) {
                List<Items> itemsList = new ArrayList<>();
                SearchHits hits = response.getHits();
                System.out.println("total hits" + hits.getTotalHits());
                System.out.println("page number" + pageable.getPageNumber());
                System.out.println("total page size" + (int) Math.ceil((double) hits.getTotalHits() / pageable.getPageSize()));
                for (SearchHit hit : hits) {
                    String highlight = hit.getHighlightFields().get(highlightField).fragments()[0].string();

                    Items items = new Items();
                    items.setItemId(hit.getSourceAsMap().get("itemId").toString());
                    items.setItemName(highlight);
                    items.setImgUrl(hit.getSourceAsMap().get("imgUrl").toString());
                    items.setPrice((Integer) hit.getSourceAsMap().get("price"));
                    items.setSellCounts((Integer) hit.getSourceAsMap().get("sellCounts"));

                    itemsList.add(items);
                }

                return new AggregatedPageImpl<T>((List<T>) itemsList, pageable, hits.getTotalHits());
            }
        });

        return items;

    }

}
