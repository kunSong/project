package org.songkun.test;

import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.songkun.Application;
import org.songkun.pojo.Stu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.SearchResultMapper;
import org.springframework.data.elasticsearch.core.aggregation.AggregatedPage;
import org.springframework.data.elasticsearch.core.aggregation.impl.AggregatedPageImpl;
import org.springframework.data.elasticsearch.core.query.*;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class TestApplication {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Test
    public void createIndex() {
        Stu stu = new Stu();
        stu.setStuId(1001L);
        stu.setName("songkun");
        stu.setAge(35);
        stu.setMoney(6.0f);
        stu.setSign("Hard Word");
        stu.setDescription("I need money");

        IndexQuery indexQuery = new IndexQueryBuilder().withObject(stu).build();
        elasticsearchTemplate.index(indexQuery);
    }

    @Test
    public void deleteIndex() {
        elasticsearchTemplate.deleteIndex(Stu.class);
    }

    @Test
    public void updateDoc() {
        Map<String, Object> source = new HashMap<>();
        source.put("name", "songchenyan");
        source.put("age", "3");

        IndexRequest indexRequest = new IndexRequest();
        indexRequest.source(source);

        UpdateQuery updateQuery = new UpdateQueryBuilder()
                .withClass(Stu.class)
                .withId("1001")
                .withIndexRequest(indexRequest)
                .build();

        elasticsearchTemplate.update(updateQuery);
    }

    @Test
    public void getOneDoc() {

        GetQuery getQuery = new GetQuery();
        getQuery.setId("1001");
        Stu stu = elasticsearchTemplate.queryForObject(getQuery, Stu.class);
        System.out.println(stu);

    }

    @Test
    public void deleteDoc() {
        elasticsearchTemplate.delete(Stu.class, "1001");
    }

    @Test
    public void searchSortDoc() {
        PageRequest pageRequest = PageRequest.of(0, 10);

        SortBuilder money = new FieldSortBuilder("money").order(SortOrder.ASC);
        SortBuilder age = new FieldSortBuilder("age").order(SortOrder.DESC);

        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.matchQuery("description", "money"))
                .withPageable(pageRequest)
                .withSort(money)
                .withSort(age)
                .build();
        AggregatedPage<Stu> stus = elasticsearchTemplate.queryForPage(searchQuery, Stu.class);
        for (Stu stu : stus.getContent()) {
            System.out.println(stu);
        }
    }

    @Test
    public void searchHightligthDocs() {

        String preTag = "<font color='red'>";
        String postTag = "</font>";

        Pageable pageRequest = PageRequest.of(0, 10);

        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.matchQuery("description", "adult"))
                .withPageable(pageRequest)
                .withHighlightFields(new HighlightBuilder.Field("description")
                    .preTags(preTag)
                    .postTags(postTag))
                .build();
        AggregatedPage<Stu> pagedStu = elasticsearchTemplate.queryForPage(searchQuery, Stu.class, new SearchResultMapper() {
            @Override
            public <T> AggregatedPage<T> mapResults(SearchResponse searchResponse, Class<T> aClass, Pageable pageable) {

                List<Stu> stus = new ArrayList<>();
                for (SearchHit hit : searchResponse.getHits()) {
                    String desc = hit.getHighlightFields().get("description").getFragments()[0].string();

                    Stu stu = new Stu();
                    Map<String, Object> stuSource = hit.getSourceAsMap();
                    stu.setStuId(Long.valueOf(stuSource.get("stuId").toString()));
                    stu.setName((String) stuSource.get("name"));
                    stu.setAge((Integer) stuSource.get("age"));
                    stu.setMoney(Float.valueOf(stuSource.get("money").toString()));
                    stu.setSign((String) stuSource.get("sign"));
                    stu.setDescription(desc);

                    stus.add(stu);

                }
                if (stus.size() > 0) {
                    return new AggregatedPageImpl<T>((List<T>) stus);
                }
                return null;
            }
        });
        System.out.println("检索后的总分页数目为：" + pagedStu.getTotalPages());
        List<Stu> stuList = pagedStu.getContent();
        for (Stu s : stuList) {
            System.out.println(s);
        }
    }


}
