package org.songkun.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.UsersBo;
import org.songkun.service.UsersService;
import org.songkun.service.impl.UsersServiceImpl;
import org.songkun.utils.CookieUtils;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.JsonUtils;
import org.songkun.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sun.security.provider.MD5;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;


@Api("用户接口")
@RestController
@RequestMapping("passport")
public class UsersController {

    @Autowired
    private UsersService usersService;

    //@CrossOrigin
    @ApiOperation(value = "查询用户是否存在", httpMethod = "GET")
    @GetMapping("/usernameIsExist")
    public IMOOCJSONResult isUsersExists(@RequestParam String username) {

        if (StringUtils.isBlank(username)) {
            return IMOOCJSONResult.errorMsg("Username cant empty");
        }
        boolean result = usersService.isUsersExists(username);
        if (result) {
            return IMOOCJSONResult.errorMsg("Exist same Username");
        }
        return IMOOCJSONResult.build(200, "No exist username", null);
    }

    @ApiOperation(value = "注册用户", httpMethod = "POST")
    @PostMapping("/regist")
    public IMOOCJSONResult registUsers(@RequestBody UsersBo usersBo) {
        if (StringUtils.isBlank(usersBo.getUsername()) ||
                StringUtils.isBlank(usersBo.getPassword()) ||
                StringUtils.isBlank(usersBo.getConfirmPassword())) {
            return IMOOCJSONResult.errorMsg("Some user info is empty");
        }
        if (usersBo.getPassword().length() < 6) {
            return IMOOCJSONResult.errorMsg("password can not less than 6");
        }
        if (!usersBo.getPassword().equals(usersBo.getConfirmPassword())) {
            return IMOOCJSONResult.errorMsg("Confirm password is typing error");
        }
        Users users = usersService.registUsers(usersBo);
        if (users == null) {
            return IMOOCJSONResult.errorMsg("register user fail");
        }
        return IMOOCJSONResult.ok(users);
    }

    @ApiOperation(value = "用户登录", httpMethod = "POST")
    @PostMapping("/login")
    public IMOOCJSONResult loginUsers(@RequestBody UsersBo usersBo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (StringUtils.isBlank(usersBo.getUsername()) ||
                StringUtils.isBlank(usersBo.getPassword())){
            return IMOOCJSONResult.errorMsg("Username or Password is not empty");
        }

        Users users = usersService.loginUsers(usersBo.getUsername(), MD5Utils.getMD5Str(usersBo.getPassword()));
        if (users == null) {
            return IMOOCJSONResult.errorMsg("username or password error");
        }

        users.setRealname(null);
        users.setPassword(null);
        users.setBirthday(null);

        // TODO 生成用户token，存入redis会话
        // TODO 同步购物车

        CookieUtils.setCookie(request, response, "user", JsonUtils.objectToJson(users), true);
        return  IMOOCJSONResult.ok(users);
    }

    @ApiOperation(value = "用户退出", httpMethod = "POST")
    @PostMapping("/logout")
    public IMOOCJSONResult logoutUsers(@RequestParam String userId, HttpServletRequest request, HttpServletResponse response) {

//        if (StringUtils.isBlank(userId)) {
//            return IMOOCJSONResult.errorMsg("userId is empty");
//        }

        // TODO 用户退出登录，需要清空购物车
        // TODO 分布式会话中需要清除用户数据

        CookieUtils.deleteCookie(request, response, "user");
        return IMOOCJSONResult.ok();
    }
}
