package org.songkun.job;

import org.songkun.mapper.OrderStatusMapper;
import org.songkun.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

//@Component
public class ScheduleJob {

    @Autowired
    private OrderService orderService;

    @Scheduled(cron = "0/5 * * * * ?")
    public void cleanUpUpaidOrders() {
        int count = orderService.cleanUpUpaidOrders();
        System.out.println("关闭了 " + count + " 条交易");

    }
}
