package org.songkun.exception;

import org.songkun.utils.IMOOCJSONResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.io.IOException;

@RestControllerAdvice
public class CustomExceptionHandler {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public IMOOCJSONResult handleMaxUploadSizeExceededException() {
        System.out.println("controller advice exceed max file size");
        return IMOOCJSONResult.errorMsg("exceed max file size");
    }

//    @ExceptionHandler
//    public void handleException(IOException ex) {
//        System.out.println(ex.getMessage());
//    }
}
