package org.songkun.controller;

import org.apache.commons.lang3.StringUtils;
import org.songkun.pojo.UserAddress;
import org.songkun.pojo.bo.AddressBo;
import org.songkun.service.AddressService;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.MobileEmailUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tk.mybatis.mapper.util.StringUtil;

import java.util.List;

@RestController
@RequestMapping("address")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @PostMapping("/list")
    public IMOOCJSONResult getAllAddressByUsers(@RequestParam String userId) {
        if (StringUtils.isBlank(userId)) {
            return IMOOCJSONResult.errorMsg("users is not login");
        }

        List<UserAddress> userAddresses = addressService.queryAllAddressByUsers(userId);
        return IMOOCJSONResult.ok(userAddresses);
    }

    @PostMapping("/add")
    public IMOOCJSONResult addNewAddress(@RequestBody AddressBo addressBo) {

        IMOOCJSONResult checkResult = checkAddress(addressBo);
        if (checkResult.getStatus() != 200) {
            return checkResult;
        }

        int result = addressService.addNewAddress(addressBo);
        if (result < 0) {
            return IMOOCJSONResult.errorMsg("insert fail");
        }
        return IMOOCJSONResult.ok();
    }

    @PostMapping("/update")
    public IMOOCJSONResult updateAddress(@RequestBody AddressBo addressBo) {

        IMOOCJSONResult checkResult = checkAddress(addressBo);
        if (checkResult.getStatus() != 200) {
            return checkResult;
        }

        int result = addressService.updateAddress(addressBo);
        if (result < 0) {
            return IMOOCJSONResult.errorMsg("update fail");
        }
        return IMOOCJSONResult.ok();
    }

    @PostMapping("/delete")
    public IMOOCJSONResult deleteAddress(@RequestParam String userId, @RequestParam String addressId) {

        if (StringUtils.isBlank(userId) || StringUtils.isBlank(addressId)) {
            return IMOOCJSONResult.errorMsg("userid or addressid cant empty");
        }

        int result = addressService.deleteAddress(userId, addressId);
        if (result < 0) {
            return IMOOCJSONResult.errorMsg("delete fail");
        }
        return IMOOCJSONResult.ok();
    }

    @PostMapping("/setDefalut")
    public IMOOCJSONResult setDefaultAddress(@RequestParam String userId, @RequestParam String addressId) {

        if (StringUtils.isBlank(userId) || StringUtils.isBlank(addressId)) {
            return IMOOCJSONResult.errorMsg("userid or addressid cant empty");
        }

        addressService.setDefaultAddress(userId, addressId);
        return IMOOCJSONResult.ok();
    }

    public IMOOCJSONResult checkAddress(AddressBo addressBo) {
        String receiver = addressBo.getReceiver();
        if (StringUtils.isBlank(receiver)) {
            return IMOOCJSONResult.errorMsg("receiver cant empty");
        }
        if (receiver.length() > 12) {
            return IMOOCJSONResult.errorMsg("receiver name too long");
        }

        String mobile = addressBo.getMobile();
        if (StringUtils.isBlank(mobile)) {
            return IMOOCJSONResult.errorMsg("mobile cannot empty");
        }
        if (mobile.length() != 11) {
            return IMOOCJSONResult.errorMsg("mobile format error");
        }
        if (!MobileEmailUtils.checkMobileIsOk(mobile)) {
            return IMOOCJSONResult.errorMsg("mobile format error");
        }

        String province = addressBo.getProvince();
        String city = addressBo.getCity();
        String district = addressBo.getDistrict();
        String detail = addressBo.getDetail();
        if (StringUtils.isBlank(province) ||
                StringUtils.isBlank(city) ||
                StringUtils.isBlank(district) ||
                StringUtils.isBlank(detail)) {
            return IMOOCJSONResult.errorMsg("收货地址信息不能为空");
        }
        return IMOOCJSONResult.ok();
    }
}
