package org.songkun;

import org.songkun.service.StuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableScheduling;
import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@ComponentScan(basePackages = {"org.songkun", "org.n3r.idworker"})
@MapperScan(basePackages = "org.songkun.mapper")
@EnableScheduling
public class Application {

    @Autowired
    private StuService stuService;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}

