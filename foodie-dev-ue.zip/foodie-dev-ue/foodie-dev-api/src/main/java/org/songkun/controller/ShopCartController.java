package org.songkun.controller;

import io.swagger.annotations.Api;
import org.songkun.pojo.Carousel;
import org.songkun.pojo.Category;
import org.songkun.pojo.bo.ShopcartItemBo;
import org.songkun.pojo.vo.CategoryVo;
import org.songkun.pojo.vo.SixNewItemsVo;
import org.songkun.service.IndexService;
import org.songkun.utils.IMOOCJSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


@Api("购物车接口")
@RestController
@RequestMapping("shopcart")
public class ShopCartController {

    @PostMapping("/add")
    public IMOOCJSONResult addItemToShopcart(@RequestParam String userId,
                                             @RequestBody ShopcartItemBo shopcartItemBo,
                                             @RequestHeader("headerUserId") String headerUserId,
                                             @RequestHeader("headerUserToken") String headerUserToken,
                                             HttpServletRequest request,
                                             HttpServletResponse response) {
        System.out.println("userId " + userId + " shopcartItemBo " + shopcartItemBo + " headUserId " + headerUserId + " headerUserToken " + headerUserToken );

        // TODO add shopcart item need sync to Redis
        return IMOOCJSONResult.ok();
    }

    @PostMapping("/del")
    public IMOOCJSONResult delItemFromShopcart(@RequestParam String userId,
                                             @RequestParam String itemSpecId,
                                             @RequestHeader("headerUserId") String headerUserId,
                                             @RequestHeader("headerUserToken") String headerUserToken,
                                             HttpServletRequest request,
                                             HttpServletResponse response) {
        System.out.println("userId " + userId + " itemSpecId " + itemSpecId + " headUserId " + headerUserId + " headerUserToken " + headerUserToken );

        // TODO del shopcart item need sync to Redis
        return IMOOCJSONResult.ok();
    }


}
