package org.songkun.controller;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.asm.IModelFilter;
import org.songkun.pojo.ItemsSpec;
import org.songkun.pojo.vo.CountsVo;
import org.songkun.pojo.vo.ItemsInfoVo;
import org.songkun.pojo.vo.ShopcartItemVo;
import org.songkun.service.ItemsService;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/items")
public class ItemsController extends BaseController{

    @Autowired
    private ItemsService itemsService;

    @GetMapping("/info/{itemId}")
    public IMOOCJSONResult getItemsInfo(@PathVariable String itemId) {

        if(StringUtils.isBlank(itemId)) {
            return IMOOCJSONResult.errorMsg("itemId can not empty");
        }

        ItemsInfoVo itemsInfoVo = buildItemsInfoVo(itemId);

        return IMOOCJSONResult.ok(itemsInfoVo);
    }

    public ItemsInfoVo buildItemsInfoVo(String itemId) {
        ItemsInfoVo itemsInfo = new ItemsInfoVo();
        itemsInfo.setItem(itemsService.queryItems(itemId));
        itemsInfo.setItemParams(itemsService.queryItemsParams(itemId));
        itemsInfo.setItemImgList(itemsService.queryItemsImage(itemId));
        itemsInfo.setItemSpecList(itemsService.queryItemsSpec(itemId));
        return itemsInfo;
    }

    @GetMapping("/commentLevel")
    public IMOOCJSONResult getItemsCommentsLevel(@RequestParam String itemId) {

        if(StringUtils.isBlank(itemId)) {
            return IMOOCJSONResult.errorMsg("itemId can not empty");
        }

        CountsVo countsVo = itemsService.queryItemsCommentLevelCount(itemId);

        return IMOOCJSONResult.ok(countsVo);
    }

    @GetMapping("/comments")
    public IMOOCJSONResult getItemsUsersComments(@RequestParam String itemId,
                                                 @RequestParam Integer level,
                                                 @RequestParam Integer page,
                                                 @RequestParam Integer pageSize) {

        if(StringUtils.isBlank(itemId)) {
            return IMOOCJSONResult.errorMsg("itemId can not empty");
        }

        if (page == null) {
            page = 1;
        }

        if (pageSize == null) {
            pageSize = DEFAULT_COMMENTS_PAGE_SIZE;
        }

        PagedGridResult usersCommentsVos = itemsService.queryItemsUsersComments(itemId, level, page, pageSize);

        return IMOOCJSONResult.ok(usersCommentsVos);
    }

    @GetMapping("/search")
    public IMOOCJSONResult doSearchItems(@RequestParam String keywords,
                                         @RequestParam String sort,
                                         @RequestParam Integer page,
                                         @RequestParam Integer pageSize) {

        if(StringUtils.isBlank(keywords)) {
            return IMOOCJSONResult.errorMsg("keywords can not empty");
        }

        if (page == null) {
            page = 1;
        }

        if (pageSize == null) {
            pageSize = DEFAULT_SEARCH_PAGE_SIZE;
        }

        PagedGridResult searchItemsVos = itemsService.searchItems(keywords, sort, page, pageSize);

        return IMOOCJSONResult.ok(searchItemsVos);
    }

    @GetMapping("/catItems")
    public IMOOCJSONResult doSearchItemsByCat(@RequestParam Integer catId,
                                              @RequestParam String sort,
                                              @RequestParam Integer page,
                                              @RequestParam Integer pageSize) {

        if(catId == null) {
            return IMOOCJSONResult.errorMsg("catId can not empty");
        }

        if (page == null) {
            page = 1;
        }

        if (pageSize == null) {
            pageSize = DEFAULT_SEARCH_PAGE_SIZE;
        }

        PagedGridResult searchItemsVos = itemsService.searchItemsByCat(catId, sort, page, pageSize);

        return IMOOCJSONResult.ok(searchItemsVos);
    }

    @GetMapping("/refresh")
    public IMOOCJSONResult refreshShopcartItems(@RequestParam String itemSpecIds) {

        if(StringUtils.isBlank(itemSpecIds)) {
            return IMOOCJSONResult.errorMsg("shopcart is empty");
        }

        String[] specIds = itemSpecIds.split(",");
        List<ShopcartItemVo> shopcartItemVos = itemsService.refreshShopcartItems(specIds);
        return IMOOCJSONResult.ok(shopcartItemVos);
    }
}
