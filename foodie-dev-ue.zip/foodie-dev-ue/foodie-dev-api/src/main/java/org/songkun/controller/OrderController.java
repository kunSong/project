package org.songkun.controller;

import org.apache.commons.lang3.StringUtils;
import org.songkun.enums.OrderStatusEnum;
import org.songkun.enums.WXOrAliPay;
import org.songkun.pojo.OrderStatus;
import org.songkun.pojo.bo.OrdersBo;
import org.songkun.pojo.bo.PaidOrdersBo;
import org.songkun.pojo.vo.MerchantOrdersVo;
import org.songkun.pojo.vo.OrderVo;
import org.songkun.service.OrderService;
import org.songkun.utils.IMOOCJSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RequestMapping("/orders")
@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/create")
    public IMOOCJSONResult createOrder(@RequestBody OrdersBo ordersBo,
                                       @RequestHeader("headerUserId") String headerUserId,
                                       @RequestHeader("headerUserToken") String headerUserToken,
                                       HttpServletRequest request,
                                       HttpServletResponse response) {

        if(StringUtils.isBlank(ordersBo.getItemSpecIds()) ||
                StringUtils.isBlank(ordersBo.getAddressId())) {
            return IMOOCJSONResult.errorMsg("items or address is empty");
        }

        if(ordersBo.getPayMethod() != WXOrAliPay.WX.type &&
                ordersBo.getPayMethod() != WXOrAliPay.ALI.type) {
            return IMOOCJSONResult.errorMsg("no support pay method");
        }
        // create order order item order status
        OrderVo orderVo = orderService.createOrder(ordersBo);

        // TODO sync redis shopcart cookie after submit order

        // submit order to payment
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("usersId", "210114123579517632512");
        headers.add("password", "123456");
        MerchantOrdersVo merchantOrdersVo = orderVo.getMerchantOrdersVo();
        merchantOrdersVo.setReturnUrl("http://localhost:8088/orders/notifyMerchantPayResult");
        HttpEntity<MerchantOrdersVo> entity = new HttpEntity<>(merchantOrdersVo, headers);

        ResponseEntity<IMOOCJSONResult> paymentResponse =
                restTemplate.postForEntity("http://localhost:8089/payment/createMerchantOrder", entity, IMOOCJSONResult.class);

        IMOOCJSONResult result = paymentResponse.getBody();
        if (result.getStatus() != 200) {
            return IMOOCJSONResult.errorMsg("payment create order error");
        }

        return IMOOCJSONResult.ok(orderVo.getOrderId());
    }

    // return_url : http://localhost:8088/orders/notifyMerchantPayResult?orderId=210129AN6AH6KD40
    @PostMapping("/notifyMerchantPayResult")
    public HttpStatus notifyMerchantPayResult(@RequestBody PaidOrdersBo paidOrdersBo) {
        if (StringUtils.isBlank(paidOrdersBo.getMchOrderId())) {
            return HttpStatus.BAD_REQUEST;
        }
        orderService.updateOrderStatus(paidOrdersBo.getMchOrderId(), OrderStatusEnum.WAITING, OrderStatusEnum.PAID);
        return HttpStatus.OK;
    }

    @PostMapping("/getPaidOrderInfo")
    public IMOOCJSONResult getPaidOrderInfo(@RequestParam String orderId) {
        if (StringUtils.isBlank(orderId)){
            return IMOOCJSONResult.errorMsg("error orderId");
        }
        OrderStatus orderStatus = orderService.queryOrderStatusByOrdersId(orderId);
        return IMOOCJSONResult.ok(orderStatus);
    }

}
