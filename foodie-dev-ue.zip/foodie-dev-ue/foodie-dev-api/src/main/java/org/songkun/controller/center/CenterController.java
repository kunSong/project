package org.songkun.controller.center;

import org.apache.commons.lang3.StringUtils;
import org.songkun.pojo.Users;
import org.songkun.pojo.vo.center.CenterUsersInfoVo;
import org.songkun.service.center.CenterUsersService;
import org.songkun.utils.IMOOCJSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;

@RestController
@RequestMapping("center")
public class CenterController {

    @Autowired
    private CenterUsersService centerUsersService;

    @GetMapping("/userInfo")
    public IMOOCJSONResult getUserInfo(@RequestParam String userId) {

        if (StringUtils.isBlank(userId)) {
            return IMOOCJSONResult.errorMsg("User Id is null");
        }
        Users info = centerUsersService.queryUsersByUsersId(userId);
        return IMOOCJSONResult.ok(info);
    }

}
