package org.songkun.controller;

public class BaseController {

    public static final Integer DEFAULT_COMMENTS_PAGE_SIZE = 10;
    public static final Integer DEFAULT_CENTER_ORDER_PAGE_SIZE = 5;
    public static final Integer DEFAULT_SEARCH_PAGE_SIZE = 20;
}
