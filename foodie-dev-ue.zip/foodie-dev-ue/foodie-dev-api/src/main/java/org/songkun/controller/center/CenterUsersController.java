package org.songkun.controller.center;


import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.songkun.config.UploadProperties;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.center.CenterUsersInfoBo;
import org.songkun.service.center.CenterUsersService;
import org.songkun.utils.CookieUtils;
import org.songkun.utils.DateUtil;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("userInfo")
public class CenterUsersController {

    @Autowired
    private CenterUsersService centerUsersService;

    @Autowired
    private UploadProperties uploadProperties;

    @PostMapping("/uploadFace")
    public IMOOCJSONResult updateUsersFace(@RequestParam String userId,
                                           HttpServletRequest request,
                                           HttpServletResponse response,
                                           MultipartFile file) {

        if (StringUtils.isBlank(userId)) {
            return IMOOCJSONResult.errorMsg("User Id cant empty");
        }
        String originFileName = file.getOriginalFilename();
        String[] splitedFileNames = originFileName.split("\\.");
        String faceNamePrefix = "face-" + splitedFileNames[0] + "-" + userId + "-" + DateUtil.dateToString(new Date());
        String faceNameSuffix = "." + splitedFileNames[1];

        if (!faceNameSuffix.equals(".jpg") && !faceNameSuffix.equals(".png") && !faceNameSuffix.equals(".jpeg")) {
            return IMOOCJSONResult.errorMsg("Photo format error");
        }

//        String path = File.separator
//                + "Users"
//                + File.separator
//                + "songkun"
//                + File.separator
//                + "Downloads"
//                + File.separator
//                + "workspace"
//                + File.separator
//                + "foodie"
//                + File.separator
//                + "uploadFace"
//                + File.separator;

        File faceFile = new File(uploadProperties.getFilePath());
        if (faceFile.getParent() != null) {
            faceFile.mkdirs();
        }

        String finalFaceName = faceNamePrefix + faceNameSuffix;

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File(faceFile, finalFaceName));
            IOUtils.copy(file.getInputStream(), out);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        String face_url = uploadProperties.getFileUrl() + finalFaceName;

        CenterUsersInfoBo infoBo = new CenterUsersInfoBo();
        infoBo.setFace(face_url);

        Users users = centerUsersService.updateUsersInfo(userId, infoBo);

        setNullProperty(users);
        CookieUtils.setCookie(request, response, "user", JsonUtils.objectToJson(users), true);
        return IMOOCJSONResult.ok();
    }

    @PostMapping("/update")
    public IMOOCJSONResult modifyUsersInfo(@RequestParam String userId,
                                           @RequestBody @Valid CenterUsersInfoBo usersInfoBo,
                                           HttpServletRequest request,
                                           HttpServletResponse response,
                                           BindingResult result) {
        if (result.hasErrors()) {
            return IMOOCJSONResult.errorMap(postErrors(result));
        }
        Users users = centerUsersService.updateUsersInfo(userId, usersInfoBo);
        if (users == null) {
            return IMOOCJSONResult.errorMsg("update userinfo fail");
        }

        setNullProperty(users);
        CookieUtils.setCookie(request, response, "user", JsonUtils.objectToJson(users), true);
        return IMOOCJSONResult.ok();
    }

    public Map<String, String> postErrors(BindingResult result) {
        Map<String, String> errorMap = new HashMap<>();
        List<FieldError> fieldErrors = result.getFieldErrors();
        for(FieldError fieldError : fieldErrors) {
            errorMap.put(fieldError.getField(), fieldError.getDefaultMessage());
        }
        return errorMap;
    }

    public void setNullProperty(Users users) {
        users.setPassword(null);
        users.setEmail(null);
        users.setMobile(null);
        users.setRealname(null);
        users.setBirthday(null);
        users.setUpdatedTime(null);
        users.setCreatedTime(null);
        users.setSex(null);
    }
}
