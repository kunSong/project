package org.songkun.controller;


import org.apache.log4j.Logger;
import org.songkun.service.OrderService;
import org.songkun.utils.IMOOCJSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.io.IOException;

@ApiIgnore
@RestController
@RequestMapping("test")
public class TestController {

    private static final Logger LOGGER = Logger.getLogger(TestController.class);

    @Autowired
    public OrderService orderService;

    @Autowired
    public ThreadPoolTaskExecutor applicationTaskExecutor;

    @GetMapping("/hello")
    public String hello() {
        return "hello world";
    }

    @GetMapping("/getUpaidOrderStatus")
    public IMOOCJSONResult getUnpaidOrderStatus() {
        //List<OrderStatus> orderStatuses = orderService.cleanUpUpaidOrders();
        return IMOOCJSONResult.ok();
    }

    @GetMapping("/exception")
    public IMOOCJSONResult testException(@RequestParam String type) throws IOException {
        if (type.equals("io")) {
            throw new IOException("IOException");
        }
        if (type.equals("illegal")) {
            IOException ioException = new IOException("wrapped IOException");
            throw new IllegalStateException(ioException);
            //throw new IllegalStateException("IllegalStateException"); 不会被@ExecptionHandler处理
        }
        return IMOOCJSONResult.ok();
    }

    @GetMapping("/applicationExecutor")
    public IMOOCJSONResult testApplicationExectuor() {
        applicationTaskExecutor.submit(() -> {LOGGER.info("ApplicationTaskExecutor runnabler run");});
        return IMOOCJSONResult.ok();
    }
}
