package org.songkun.controller.center;

import org.songkun.controller.BaseController;
import org.songkun.service.center.CenterOrdersService;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("myorders")
public class CenterOrderController extends BaseController{

    @Autowired
    private CenterOrdersService centerOrdersService;

    @PostMapping("/query")
    public IMOOCJSONResult getOrdersList(String userId,
                                         String orderStatus,
                                         Integer page,
                                         Integer pageSize) {
        if (page == null) {
            page = 1;
        }
        if (pageSize == null) {
            pageSize = DEFAULT_CENTER_ORDER_PAGE_SIZE;
        }

        PagedGridResult pagedGridResult = centerOrdersService.queryOrdersByOrderStatus(userId, orderStatus, page, pageSize);

        return IMOOCJSONResult.ok(pagedGridResult);
    }

}
