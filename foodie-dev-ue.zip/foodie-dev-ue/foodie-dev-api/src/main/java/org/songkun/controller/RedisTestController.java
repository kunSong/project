package org.songkun.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("redis")
public class RedisTestController {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @GetMapping("/set")
    public String setValue(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
        return "ok";
    }

    @GetMapping("/get")
    public String getValue(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    @GetMapping("/update")
    public String updateValue(String key, String value) {
        Boolean result = redisTemplate.opsForValue().setIfPresent(key, value);
        return result ? "present" : "absent";
    }

    @GetMapping("/del")
    public String deleteValue(String key) {
        redisTemplate.delete(key);
        return "ok";
    }



}
