package org.songkun.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ServiceLogAspect {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceLogAspect.class);

    @Pointcut("execution(* org.songkun.service..*(..))")
    public void pointcut() {
    }

//    @Around("pointcut() && args(username)")
//    //@Around("pointcut()")
//    public Object calServiceRuntime2(ProceedingJoinPoint point, String username) throws Throwable {
//
//        LOGGER.info("ServiceLogAspect args target class name {}", username);
//        long begin = System.currentTimeMillis();
//        Object object = point.proceed();
//        long end = System.currentTimeMillis();
//
//        long result = end - begin;
//
//        if (result > 3000) {
//            LOGGER.warn("service run too much time {}", result);
//        } else {
//            LOGGER.info("service run time {}", result);
//        }
//
//        return object;
//
//    }

    @Around("pointcut()")
    public Object calServiceRuntime(ProceedingJoinPoint point) throws Throwable {

        long begin = System.currentTimeMillis();
        Object object = point.proceed();
        long end = System.currentTimeMillis();

        long result = end - begin;

        if (result > 3000) {
            LOGGER.warn("service run too much time {}", result);
        } else {
            LOGGER.info("service run time {}", result);
        }

        return object;

    }

    // Users loginUsers(String username, String password);
//    @Before("execution(* org.songkun.service.UsersService.loginUsers(..))")
//    public void  calBefore(JoinPoint point) {
//        LOGGER.info("advice before");
//    }
//
//    @Before("pointcut()")
//    public void  calBefore2(JoinPoint point) {
//        LOGGER.info("advice before 2");
//    }
//
//    @After("pointcut()")
//    public void  calAfter(JoinPoint point) {
//        LOGGER.info("advice after");
//    }
//
//    @AfterReturning("pointcut()")
//    public void  calAfterReturning(JoinPoint point) {
//        LOGGER.info("advice after returning");
//    }
//
//    @AfterThrowing("pointcut()")
//    public void  calAfterThrowing(JoinPoint point) {
//        LOGGER.info("advice after throwing");
//    }


}
