package org.songkun.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.songkun.pojo.Carousel;
import org.songkun.pojo.Category;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.UsersBo;
import org.songkun.pojo.vo.CategoryVo;
import org.songkun.pojo.vo.SixNewItemsVo;
import org.songkun.service.IndexService;
import org.songkun.service.UsersService;
import org.songkun.utils.CookieUtils;
import org.songkun.utils.IMOOCJSONResult;
import org.songkun.utils.JsonUtils;
import org.songkun.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


@Api("首页接口")
@RestController
@RequestMapping("index")
public class IndexController {

    @Autowired
    private IndexService indexService;

    @GetMapping("/carousel")
    public IMOOCJSONResult getIndexCarousel() {
        List<Carousel> carousels = indexService.queryAllCarousel();
        return IMOOCJSONResult.ok(carousels);
    }

    @GetMapping("/cats")
    public IMOOCJSONResult getIndexMainCategory() {
        List<Category> categories = indexService.queryIndexMainCategory();
        return IMOOCJSONResult.ok(categories);
    }

    @GetMapping("/subCat/{rootId}")
    public IMOOCJSONResult getIndexSubCategory(@PathVariable Integer rootId) {
        if (rootId == null) {
            return IMOOCJSONResult.errorMsg("Root Category Id is empty");
        }
        List<CategoryVo> subCategory = indexService.queryIndexSubCategory(rootId);
        return IMOOCJSONResult.ok(subCategory);
    }

    @GetMapping("/sixNewItems/{rootId}")
    public IMOOCJSONResult getIndexSixNewItems(@PathVariable Integer rootId) {
        if (rootId == null) {
            return IMOOCJSONResult.errorMsg("Root Category Id is empty");
        }
        List<SixNewItemsVo> sixNewItemsVos = indexService.queryIndexSixNewItems(rootId);
        return IMOOCJSONResult.ok(sixNewItemsVos);

    }
}
