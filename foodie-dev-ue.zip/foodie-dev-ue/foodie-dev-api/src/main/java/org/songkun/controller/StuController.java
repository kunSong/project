package org.songkun.controller;

import org.songkun.pojo.Stu;
import org.songkun.service.StuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
@RequestMapping("stu")
public class StuController {

    @Autowired
    private StuService stuService;

    @GetMapping("/save")
    public String save() {
        return stuService.save() > 0 ? "ok" : "error";
    }

    @GetMapping("/query/{id}")
    public Stu query(@PathVariable int id) {
        return stuService.getStudent(id);
    }

    @GetMapping("/update")
    public String update(int id) {
        return stuService.updateStudent(id, "chenhuihui") > 0 ? "ok" : "error";
    }

    @GetMapping("/delete")
    public String delete(int id) {
        return stuService.deleteStudent(id) > 0 ? "ok" : "error";
    }
}
