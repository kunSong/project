package org.songkun.test.transaction;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.songkun.service.StuService;
import org.songkun.service.TestStuService;
import org.springframework.aop.framework.Advised;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class TransactionalPropagationTest {

    @Autowired
    private StuService stuService;

    @Autowired
    private TestStuService testStuService;

//    @Test
    public void test() {
        testStuService.testStuTransactional();
//        stuService.testTransactional();
    }

}
