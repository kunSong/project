package org.songkun.mapper;

import org.apache.ibatis.annotations.Param;
import org.songkun.pojo.vo.CategoryVo;
import org.songkun.pojo.vo.SixNewItemsVo;

import java.util.List;
import java.util.Map;

public interface CustomCategoryMapper {

    List<CategoryVo> queryIndexSubCategory(@Param("rootId") Integer rootId);

    List<SixNewItemsVo> queryIndexSixNewItems(@Param("paramsMap") Map<String, Object> map);
}