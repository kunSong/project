package org.songkun.mapper;

import org.apache.ibatis.annotations.Param;
import org.songkun.pojo.vo.center.CenterOrdersVo;

import java.util.List;
import java.util.Map;

public interface CustomOrdersMapper {

    List<CenterOrdersVo> queryOrdersByOrderStatus(@Param("paramsMap")Map<String, Object> map);
}
