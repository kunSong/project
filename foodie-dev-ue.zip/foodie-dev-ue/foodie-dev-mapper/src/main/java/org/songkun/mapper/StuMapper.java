package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.Stu;

public interface StuMapper extends MyMapper<Stu> {
}