package org.songkun.mapper;

import org.apache.ibatis.annotations.Param;
import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.ItemsComments;
import org.songkun.pojo.vo.UsersCommentsVo;

import java.util.List;
import java.util.Map;

public interface CustomItemsCommentsMapper {

    List<UsersCommentsVo> queryUsersComments(@Param("paramsMap") Map<String, Object> maps);
}