package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.ItemsSpec;

public interface ItemsSpecMapper extends MyMapper<ItemsSpec> {
}