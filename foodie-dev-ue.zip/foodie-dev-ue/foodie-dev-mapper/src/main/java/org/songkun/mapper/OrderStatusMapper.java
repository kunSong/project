package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.OrderStatus;

public interface OrderStatusMapper extends MyMapper<OrderStatus> {
}