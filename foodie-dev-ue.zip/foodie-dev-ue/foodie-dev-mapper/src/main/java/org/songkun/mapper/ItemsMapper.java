package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.Items;

public interface ItemsMapper extends MyMapper<Items> {
}