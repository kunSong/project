package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.Users;

public interface UsersMapper extends MyMapper<Users> {
}