package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.ItemsComments;

public interface ItemsCommentsMapper extends MyMapper<ItemsComments> {
}