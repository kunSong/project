package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.ItemsParam;

public interface ItemsParamMapper extends MyMapper<ItemsParam> {
}