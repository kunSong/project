package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.OrderItems;

public interface OrderItemsMapper extends MyMapper<OrderItems> {
}