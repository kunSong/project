package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.Category;

public interface CategoryMapper extends MyMapper<Category> {
}