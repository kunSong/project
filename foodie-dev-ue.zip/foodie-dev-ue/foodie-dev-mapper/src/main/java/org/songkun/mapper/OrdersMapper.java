package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.Orders;

public interface OrdersMapper extends MyMapper<Orders> {
}