package org.songkun.mapper;

import org.apache.ibatis.annotations.Param;
import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.Items;
import org.songkun.pojo.vo.SearchVo;
import org.songkun.pojo.vo.ShopcartItemVo;

import java.util.List;
import java.util.Map;

public interface CustomItemsMapper {

    List<SearchVo> searchItems(@Param("paramsMap") Map<String, Object> map);

    List<SearchVo> searchItemsByCat(@Param("paramsMap") Map<String, Object> map);

    List<ShopcartItemVo> refreshShopcartItems(@Param("paramsList") List<String> list);

    int updateItemsSpecWithStockByItemsSpecId(@Param("paramsMap") Map<String, Object> map);
}