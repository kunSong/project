package org.songkun.mapper;

import org.songkun.my.mapper.MyMapper;
import org.songkun.pojo.ItemsImg;

public interface ItemsImgMapper extends MyMapper<ItemsImg> {
}