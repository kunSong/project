package org.songkun.service;

import org.apache.ibatis.annotations.Param;
import org.songkun.pojo.UserAddress;
import org.songkun.pojo.bo.AddressBo;

import java.util.List;

public interface AddressService {

    List<UserAddress> queryAllAddressByUsers(String userId);

    int addNewAddress(AddressBo addressBo);

    int updateAddress(AddressBo addressBo);

    int deleteAddress(String userId, String addressId);

    void setDefaultAddress(String userId, String addressId);

    UserAddress queryUserDefaultAddress(String userId);

    UserAddress queryUserAddress(String userId, String addressId);
}
