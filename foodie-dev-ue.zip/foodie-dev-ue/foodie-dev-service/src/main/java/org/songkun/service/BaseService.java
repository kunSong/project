package org.songkun.service;

import com.github.pagehelper.PageInfo;
import org.songkun.utils.PagedGridResult;

import java.util.List;

public class BaseService {

    public PagedGridResult setPageInfo(List<?> list) {
        PageInfo<?> pageInfo = new PageInfo(list);
        PagedGridResult commentsInfo = new PagedGridResult();
        commentsInfo.setRecords(pageInfo.getTotal());
        commentsInfo.setTotal(pageInfo.getPages());
        commentsInfo.setRows(list);
        return commentsInfo;
    }
}
