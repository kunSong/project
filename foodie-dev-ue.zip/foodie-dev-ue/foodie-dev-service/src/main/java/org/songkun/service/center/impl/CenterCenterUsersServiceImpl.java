package org.songkun.service.center.impl;

import org.songkun.mapper.UsersMapper;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.center.CenterUsersInfoBo;
import org.songkun.pojo.vo.center.CenterUsersInfoVo;
import org.songkun.service.center.CenterUsersService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class CenterCenterUsersServiceImpl implements CenterUsersService {

    @Autowired
    private UsersMapper usersMapper;

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Users queryUsersByUsersId(String userId) {
        Users users = new Users();
        users.setId(userId);
        Users usersQuery = usersMapper.selectByPrimaryKey(users);
        return usersQuery;
    }

    @Override
    public Users updateUsersInfo(String userId, CenterUsersInfoBo usersInfoBo) {
        Users users = new Users();
        users.setId(userId);
        users.setNickname(usersInfoBo.getNickname());
        users.setRealname(usersInfoBo.getRealname());
        users.setEmail(usersInfoBo.getEmail());
        users.setMobile(usersInfoBo.getMobile());
        users.setBirthday(usersInfoBo.getBirthday());
        users.setFace(usersInfoBo.getFace());
        users.setSex(usersInfoBo.getSex());
        users.setUpdatedTime(new Date());
        int count = usersMapper.updateByPrimaryKeySelective(users);
        if (count == 1) {
            return queryUsersByUsersId(userId);
        }
        return null;
    }


}
