package org.songkun.service.center;

import org.songkun.utils.PagedGridResult;

public interface CenterOrdersService {

    PagedGridResult queryOrdersByOrderStatus(String userId, String orderStatus, Integer page, Integer pageSize);
}
