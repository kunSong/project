package org.songkun.service.impl;

import org.n3r.idworker.Sid;
import org.songkun.enums.OrderStatusEnum;
import org.songkun.enums.YesOrNo;
import org.songkun.mapper.*;
import org.songkun.pojo.*;
import org.songkun.pojo.bo.OrdersBo;
import org.songkun.pojo.vo.MerchantOrdersVo;
import org.songkun.pojo.vo.OrderVo;
import org.songkun.service.AddressService;
import org.songkun.service.ItemsService;
import org.songkun.service.OrderService;
import org.songkun.utils.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import sun.security.jgss.spi.MechanismFactory;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrdersMapper ordersMapper;

    @Autowired
    private AddressService addressService;

    @Autowired
    private ItemsService itemsService;

    @Autowired
    private OrderItemsMapper orderItemsMapper;

    @Autowired
    private OrderStatusMapper orderStatusMapper;

    @Autowired
    private Sid sid;

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public OrderVo createOrder(OrdersBo ordersBo) {

        String addressId = ordersBo.getAddressId();
        String[] itemSpecIds = ordersBo.getItemSpecIds().split(",");
        Integer payMethod = ordersBo.getPayMethod();
        String orderRemarker = ordersBo.getLeftMsg();
        String userId = ordersBo.getUserId();
        int postAmount = 0;

        Orders orders = new Orders();
        orders.setId(sid.nextShort());
        orders.setUserId(userId);
        orders.setPostAmount(postAmount); // 免邮
        orders.setLeftMsg(orderRemarker);
        orders.setPayMethod(payMethod);
        orders.setIsComment(YesOrNo.NO.type);
        orders.setIsDelete(YesOrNo.NO.type);

        int totalAmount = 0;
        int realPayAmount = 0;
        // 按商品规格id遍历商品
        for(String itemSpecId : itemSpecIds) {

            // TODO 需要从Redis中的购物车查询出
            int buyCount = 1;

            // 这里没有使用级联查询、而是分开的单表依次查询
            // 按商品规格查询，获得商品id、商品价格、商品库存
            ItemsSpec itemsSpec = itemsService.queryItemSpecByItemSpecId(itemSpecId);
            totalAmount += itemsSpec.getPriceNormal() * buyCount;
            realPayAmount += itemsSpec.getPriceDiscount() * buyCount;

            String itemsId = itemsSpec.getItemId();
            // 根据商品id，查询商品图片
            ItemsImg itemsImg = itemsService.queryItemsImageByMainImage(itemsId);

            // 根据商品id，查询商品信息
            Items items = itemsService.queryItems(itemsId);

            // 订单商品的快照信息保存
            OrderItems orderItems = new OrderItems();
            orderItems.setId(sid.nextShort());
            orderItems.setOrderId(orders.getId());
            orderItems.setItemId(itemsId);
            orderItems.setItemName(items.getItemName());
            orderItems.setItemImg(itemsImg.getUrl());
            orderItems.setBuyCounts(buyCount);
            orderItems.setItemSpecId(itemSpecId);
            orderItems.setItemSpecName(itemsSpec.getName());
            orderItems.setPrice(itemsSpec.getPriceDiscount());
            orderItemsMapper.insert(orderItems);

            // 修改商品库存，因为是多线程访问，会有并发超卖问题，所以使用分布式锁，zookeeper或redis，暂时使用数据库乐观锁
            itemsService.updateItemsSpecWithStockByItemsSpecId(itemSpecId, buyCount);
        }

        // 地址查询，设置订单地址快照
        UserAddress userAddressQueried = addressService.queryUserAddress(userId, addressId);
        orders.setReceiverAddress(userAddressQueried.getCity()
                + " " + userAddressQueried.getProvince()
                + " " + userAddressQueried.getDistrict()
                + " " + userAddressQueried.getDetail());
        orders.setReceiverName(userAddressQueried.getReceiver());
        orders.setReceiverMobile(userAddressQueried.getMobile());

        // 遍历商品后设置价格
        orders.setTotalAmount(totalAmount);
        orders.setRealPayAmount(realPayAmount);
        orders.setUpdatedTime(new Date());
        orders.setCreatedTime(new Date());
        ordersMapper.insert(orders);

        // 订单状态
        OrderStatus orderStatus = new OrderStatus();
        orderStatus.setOrderId(orders.getId());
        orderStatus.setOrderStatus(OrderStatusEnum.WAITING.type);
        orderStatus.setCreatedTime(new Date());
        orderStatusMapper.insert(orderStatus);

        MerchantOrdersVo merchantOrdersVo = new MerchantOrdersVo();
        merchantOrdersVo.setMerchantOrderId(orders.getId());
        merchantOrdersVo.setMerchantUserId(userId);
        merchantOrdersVo.setAmount(orders.getRealPayAmount() + postAmount);
        merchantOrdersVo.setPayMethod(payMethod);

        OrderVo orderVo = new OrderVo();
        orderVo.setOrderId(orders.getId());
        orderVo.setMerchantOrdersVo(merchantOrdersVo);

        return orderVo;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void updateOrderStatus(String orderId, OrderStatusEnum oldOrderStatus, OrderStatusEnum newOrderStatus) {
        OrderStatus orderStatus = new OrderStatus();
        orderStatus.setOrderId(orderId);
        orderStatus.setOrderStatus(newOrderStatus.type);
        orderStatus.setPayTime(new Date());

        Example example = new Example(OrderStatus.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("orderId", orderId);
        criteria.andEqualTo("orderStatus", oldOrderStatus.type);
        orderStatusMapper.updateByExampleSelective(orderStatus, example);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public OrderStatus queryOrderStatusByOrdersId(String orderId) {
        OrderStatus orderStatus = new OrderStatus();
        orderStatus.setOrderId(orderId);

        return orderStatusMapper.selectByPrimaryKey(orderStatus);
    }

    @Override
    public int cleanUpUpaidOrders() {
//        Example example = new Example(OrderStatus.class);
//        Example.Criteria criteria = example.createCriteria();
//        criteria.andEqualTo("orderStatus", OrderStatusEnum.WAITING.type);
//        criteria.andLessThan("createdTime", DateUtil.convertToDate("2021-02-04 00:00"));
        int count = 0;
        OrderStatus orderStatus = new OrderStatus();
        orderStatus.setOrderStatus(OrderStatusEnum.WAITING.type);
        List<OrderStatus> orderStatuses = orderStatusMapper.select(orderStatus);
        for(OrderStatus unpaidOrderStatus : orderStatuses) {
            unpaidOrderStatus.setOrderStatus(OrderStatusEnum.CLOSED.type);
            unpaidOrderStatus.setCloseTime(new Date());
            count += orderStatusMapper.updateByPrimaryKeySelective(unpaidOrderStatus);
        }

        return count;

    }
}
