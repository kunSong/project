package org.songkun.service;

import org.songkun.enums.OrderStatusEnum;
import org.songkun.pojo.OrderStatus;
import org.songkun.pojo.bo.OrdersBo;
import org.songkun.pojo.vo.OrderVo;

import java.util.List;

public interface OrderService {

    OrderVo createOrder(OrdersBo ordersBo);

    void updateOrderStatus(String orderId, OrderStatusEnum oldOrderStatus, OrderStatusEnum newOrderStatus);

    OrderStatus queryOrderStatusByOrdersId(String orderId);

    int cleanUpUpaidOrders();
}

