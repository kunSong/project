package org.songkun.service.impl;

import org.n3r.idworker.Sid;
import org.songkun.enums.ItemCategory;
import org.songkun.enums.Sex;
import org.songkun.enums.YesOrNo;
import org.songkun.mapper.CarouselMapper;
import org.songkun.mapper.CategoryMapper;
import org.songkun.mapper.CustomCategoryMapper;
import org.songkun.mapper.UsersMapper;
import org.songkun.pojo.Carousel;
import org.songkun.pojo.Category;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.UsersBo;
import org.songkun.pojo.vo.CategoryVo;
import org.songkun.pojo.vo.SixNewItemsVo;
import org.songkun.service.IndexService;
import org.songkun.service.UsersService;
import org.songkun.utils.DateUtil;
import org.songkun.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IndexServiceImpl implements IndexService {

    @Autowired
    private CarouselMapper carouselMapper;

    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private CustomCategoryMapper customCategoryMapper;

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<Carousel> queryAllCarousel() {
        Example example = new Example(Carousel.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("isShow", YesOrNo.YES.type);
        example.orderBy("sort");
        return carouselMapper.selectByExample(example);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<Category> queryIndexMainCategory() {
        Example example = new Example(Category.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("type", ItemCategory.TOP_CATEGORY.type);
        return categoryMapper.selectByExample(example);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<CategoryVo> queryIndexSubCategory(Integer rootCatId) {
        return customCategoryMapper.queryIndexSubCategory(rootCatId);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<SixNewItemsVo> queryIndexSixNewItems(Integer rootId) {
        Map<String, Object> paramsMap = new HashMap();
        paramsMap.put("rootId", rootId);
        return customCategoryMapper.queryIndexSixNewItems(paramsMap);
    }
}
