package org.songkun.service;

import org.songkun.pojo.*;
import org.songkun.pojo.vo.CountsVo;
import org.songkun.pojo.vo.ShopcartItemVo;
import org.songkun.utils.PagedGridResult;

import java.util.List;

public interface ItemsService {

    Items queryItems(String itemId);

    ItemsParam queryItemsParams(String itemId);

    List<ItemsImg> queryItemsImage(String itemId);

    List<ItemsSpec> queryItemsSpec(String itemId);

    CountsVo queryItemsCommentLevelCount(String itemId);

    PagedGridResult queryItemsUsersComments(String ItemId, Integer level, Integer page, Integer pageSize);

    PagedGridResult searchItems(String keywords, String sort, Integer page, Integer pageSize);

    PagedGridResult searchItemsByCat(Integer catId, String sort, Integer page, Integer pageSize);

    List<ShopcartItemVo> refreshShopcartItems(String[] specIds);

    ItemsSpec queryItemSpecByItemSpecId(String itemsSpecId);

    ItemsImg queryItemsImageByMainImage(String itemId);

    void updateItemsSpecWithStockByItemsSpecId(String itemsSpecId, int buyCount);

}
