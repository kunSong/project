package org.songkun.service.impl;

import org.n3r.idworker.Sid;
import org.songkun.enums.YesOrNo;
import org.songkun.mapper.UserAddressMapper;
import org.songkun.pojo.UserAddress;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.AddressBo;
import org.songkun.service.AddressService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.List;

@Service
public class AddressServiceImpl implements AddressService {

    @Autowired
    private UserAddressMapper userAddressMapper;

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<UserAddress> queryAllAddressByUsers(String userId) {

        UserAddress userAddress = new UserAddress();
        userAddress.setUserId(userId);

        List<UserAddress> userAddresses = userAddressMapper.select(userAddress);

        return userAddresses;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public int addNewAddress(AddressBo addressBo) {

        UserAddress newUserAddress = new UserAddress();
        List<UserAddress> userAddresses = queryAllAddressByUsers(addressBo.getUserId());
        if (userAddresses == null || userAddresses.size() == 0 || userAddresses.isEmpty()) {
            newUserAddress.setIsDefault(YesOrNo.YES.type);
        }
        BeanUtils.copyProperties(addressBo, newUserAddress);
        newUserAddress.setId(Sid.next());
        newUserAddress.setCreatedTime(new Date());
        newUserAddress.setUpdatedTime(new Date());
        return userAddressMapper.insertSelective(newUserAddress);
    }


    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public int updateAddress(AddressBo addressBo) {
        UserAddress updateUserAddress = new UserAddress();

        BeanUtils.copyProperties(addressBo, updateUserAddress);
        updateUserAddress.setId(addressBo.getAddressId());
        updateUserAddress.setUpdatedTime(new Date());
        return userAddressMapper.updateByPrimaryKeySelective(updateUserAddress);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public int deleteAddress(String userId, String addressId) {
        UserAddress deleteAddress = new UserAddress();

        deleteAddress.setId(addressId);
        deleteAddress.setUserId(userId);
        return userAddressMapper.delete(deleteAddress);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void setDefaultAddress(String userId, String addressId) {

        UserAddress oldDefaultAddress = queryUserDefaultAddress(userId);
        oldDefaultAddress.setIsDefault(YesOrNo.NO.type);
        userAddressMapper.updateByPrimaryKeySelective(oldDefaultAddress);

        UserAddress newDefaultAddress = new UserAddress();
        newDefaultAddress.setId(addressId);
        newDefaultAddress.setUserId(userId);
        newDefaultAddress.setIsDefault(YesOrNo.YES.type);
        userAddressMapper.updateByPrimaryKeySelective(newDefaultAddress);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public UserAddress queryUserDefaultAddress(String userId) {
        UserAddress defaultAddress = new UserAddress();

        defaultAddress.setUserId(userId);
        defaultAddress.setIsDefault(YesOrNo.YES.type);
        return userAddressMapper.selectOne(defaultAddress);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public UserAddress queryUserAddress(String userId, String addressId) {
        UserAddress userAddress = new UserAddress();
        userAddress.setUserId(userId);
        userAddress.setId(addressId);
        return userAddressMapper.selectOne(userAddress);
    }
}
