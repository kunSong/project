package org.songkun.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.songkun.enums.CommentsLevel;
import org.songkun.enums.YesOrNo;
import org.songkun.mapper.*;
import org.songkun.pojo.*;
import org.songkun.pojo.vo.CountsVo;
import org.songkun.pojo.vo.SearchVo;
import org.songkun.pojo.vo.ShopcartItemVo;
import org.songkun.pojo.vo.UsersCommentsVo;
import org.songkun.service.ItemsService;
import org.songkun.utils.DesensitizationUtil;
import org.songkun.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.*;

@Service
public class ItemsServiceImpl implements ItemsService {

    @Autowired
    private ItemsMapper itemsMapper;

    @Autowired
    private ItemsSpecMapper itemsSpecMapper;

    @Autowired
    private ItemsImgMapper itemsImgMapper;

    @Autowired
    private ItemsParamMapper itemsParamMapper;

    @Autowired
    private ItemsCommentsMapper itemsCommentsMapper;

    @Autowired
    private CustomItemsCommentsMapper customItemsCommentsMapper;

    @Autowired
    private CustomItemsMapper customItemsMapper;

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public Items queryItems(String itemId) {
        Example example = new Example(Items.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("id", itemId);
        Items items = itemsMapper.selectOneByExample(example);
        return items;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public ItemsParam queryItemsParams(String itemId) {
        Example example = new Example(ItemsParam.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId", itemId);
        ItemsParam itemsParam = itemsParamMapper.selectOneByExample(example);
        return itemsParam;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<ItemsImg> queryItemsImage(String itemId) {
        Example example = new Example(ItemsImg.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId", itemId);
        example.orderBy("sort");
        List<ItemsImg> itemsImg = itemsImgMapper.selectByExample(example);
        return itemsImg;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<ItemsSpec> queryItemsSpec(String itemId) {
        Example example = new Example(ItemsSpec.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId", itemId);
        List<ItemsSpec> itemsSpec = itemsSpecMapper.selectByExample(example);
        return itemsSpec;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public CountsVo queryItemsCommentLevelCount(String itemId) {

        int good = queryItemsCommentsCountByLevel(itemId, CommentsLevel.GOOD.type);
        int medium = queryItemsCommentsCountByLevel(itemId, CommentsLevel.MEDIUM.type);
        int bad = queryItemsCommentsCountByLevel(itemId, CommentsLevel.BAD.type);
        int total = good + medium + bad;
        CountsVo countsVo = new CountsVo();
        countsVo.setGoodCounts(good);
        countsVo.setNormalCounts(medium);
        countsVo.setBadCounts(bad);
        countsVo.setTotalCounts(total);
        return countsVo;
    }

    public int queryItemsCommentsCountByLevel(String itemId, int level) {
        ItemsComments itemsCommentsCondition = new ItemsComments();
        itemsCommentsCondition.setItemId(itemId);
        itemsCommentsCondition.setCommentLevel(level);
        int result = itemsCommentsMapper.selectCount(itemsCommentsCondition);
        return result;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult queryItemsUsersComments(String ItemId, Integer level, Integer page, Integer pageSize) {
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("itemId", ItemId);
        paramsMap.put("level", level);

        PageHelper.startPage(page, pageSize);

        List<UsersCommentsVo> usersCommentsVos = customItemsCommentsMapper.queryUsersComments(paramsMap);
        for (UsersCommentsVo usersCommentsVo : usersCommentsVos) {
            usersCommentsVo.setNickname(DesensitizationUtil.commonDisplay(usersCommentsVo.getNickname()));
        }
        return setPageInfo(usersCommentsVos);
    }

    public PagedGridResult setPageInfo(List<?> list) {
        PageInfo<?> pageInfo = new PageInfo(list);
        PagedGridResult commentsInfo = new PagedGridResult();
        commentsInfo.setRecords(pageInfo.getTotal());
        commentsInfo.setTotal(pageInfo.getPages());
        commentsInfo.setRows(list);
        return commentsInfo;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult searchItems(String keywords, String sort, Integer page, Integer pageSize) {
        Map<String, Object> map = new HashMap<>();
        map.put("keywords", keywords);
        map.put("sort", sort);

        PageHelper.startPage(page, pageSize);

        List<SearchVo> searchVos = customItemsMapper.searchItems(map);

        return setPageInfo(searchVos);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult searchItemsByCat(Integer catId, String sort, Integer page, Integer pageSize) {
        Map<String, Object> map = new HashMap<>();
        map.put("catId", catId);
        map.put("sort", sort);

        PageHelper.startPage(page, pageSize);

        List<SearchVo> searchVos = customItemsMapper.searchItemsByCat(map);

        return setPageInfo(searchVos);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<ShopcartItemVo> refreshShopcartItems(String[] specIds) {

        List<String> list = Arrays.asList(specIds);
        //Collections.addAll(list, specIds);
        List<ShopcartItemVo> shopcartItemVos = customItemsMapper.refreshShopcartItems(list);
        return shopcartItemVos;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public ItemsSpec queryItemSpecByItemSpecId(String itemsSpecId) {
        ItemsSpec itemsSpec = new ItemsSpec();
        itemsSpec.setId(itemsSpecId);
        return itemsSpecMapper.selectByPrimaryKey(itemsSpec);
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public ItemsImg queryItemsImageByMainImage(String itemId) {
        Example example = new Example(ItemsImg.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId", itemId);
        criteria.andEqualTo("isMain", YesOrNo.YES.type);
        return itemsImgMapper.selectOneByExample(example);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void updateItemsSpecWithStockByItemsSpecId(String itemsSpecId, int buyCount) {
        // TODO 使用分布式锁获取锁

        // 更新库存
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("itemsSpecId", itemsSpecId);
        paramsMap.put("buyCount", buyCount);
        int result = customItemsMapper.updateItemsSpecWithStockByItemsSpecId(paramsMap);
        if (result != 1) {
            throw new RuntimeException("no enough stock");
        }
        // TODO 使用分布式锁释放锁
    }

}