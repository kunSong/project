package org.songkun.service;

import org.songkun.pojo.Users;
import org.songkun.pojo.bo.UsersBo;

public interface UsersService {

    boolean isUsersExists(String username);

    Users registUsers(UsersBo users);

    Users loginUsers(String username, String password);

}
