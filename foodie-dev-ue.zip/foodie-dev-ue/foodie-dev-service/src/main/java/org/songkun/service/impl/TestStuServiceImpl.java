package org.songkun.service.impl;

import org.songkun.pojo.Stu;
import org.songkun.service.StuService;
import org.songkun.service.TestStuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TestStuServiceImpl implements TestStuService {

    @Autowired
    private StuService stuService;

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void testStuTransactional() {
        stuService.saveParent();
        stuService.saveChild();
//        int i = 1/0;
    }
}
