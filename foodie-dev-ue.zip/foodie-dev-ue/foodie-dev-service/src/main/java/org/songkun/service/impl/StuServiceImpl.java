package org.songkun.service.impl;

import org.songkun.mapper.StuMapper;
import org.songkun.pojo.Stu;
import org.songkun.service.StuService;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StuServiceImpl implements StuService {

    @Autowired
    private StuMapper stuMapper;


    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public int save() {
        Stu stu = new Stu();
        stu.setName("songkun");
        stu.setAge(33);
        return stuMapper.insert(stu);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Stu getStudent(int id) {
        return stuMapper.selectByPrimaryKey(id);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public int updateStudent(int id, String name) {
        Stu stuModified = stuMapper.selectByPrimaryKey(id);
        stuModified.setName(name);
        return stuMapper.updateByPrimaryKey(stuModified);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public int deleteStudent(int id) {
        return stuMapper.deleteByPrimaryKey(id);
    }

//    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void testTransactional() {
//      Set 'exposeProxy' property on Advised to 'true' to make it available
        StuService  stuService = (StuService) AopContext.currentProxy();
        stuService.saveParent();
        stuService.saveChild();
//        int i = 1/0;
    }

    @Override
    public void saveParent() {
        Stu parent = new Stu();
        parent.setName("songkun");
        parent.setAge(33);
        stuMapper.insert(parent);
    }

    @Transactional(propagation = Propagation.NESTED)
    @Override
    public void saveChild() {
        Stu child = new Stu();
        child.setName("songchenyan");
        child.setAge(3);
        stuMapper.insert(child);
        try {
            int i = 1 / 0;
        } catch (Exception ex) {

        }
    }
}
