package org.songkun.service;

import org.songkun.pojo.Carousel;
import org.songkun.pojo.Category;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.UsersBo;
import org.songkun.pojo.vo.CategoryVo;
import org.songkun.pojo.vo.SixNewItemsVo;

import java.util.List;

public interface IndexService {

    List<Carousel> queryAllCarousel();

    List<Category> queryIndexMainCategory();

    List<CategoryVo> queryIndexSubCategory(Integer rootId);

    List<SixNewItemsVo> queryIndexSixNewItems(Integer rootId);

}
