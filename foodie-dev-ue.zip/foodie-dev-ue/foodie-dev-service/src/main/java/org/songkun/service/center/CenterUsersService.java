package org.songkun.service.center;

import org.songkun.pojo.Users;
import org.songkun.pojo.bo.center.CenterUsersInfoBo;
import org.songkun.pojo.vo.center.CenterUsersInfoVo;

public interface CenterUsersService {

    Users queryUsersByUsersId(String userId);

    Users updateUsersInfo(String userId, CenterUsersInfoBo usersInfoBo);
}
