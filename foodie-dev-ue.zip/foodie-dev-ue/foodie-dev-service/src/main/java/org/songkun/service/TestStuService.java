package org.songkun.service;

public interface TestStuService {

    void testStuTransactional();
}
