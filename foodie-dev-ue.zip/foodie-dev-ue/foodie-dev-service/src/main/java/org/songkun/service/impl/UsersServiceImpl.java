package org.songkun.service.impl;

import org.n3r.idworker.Sid;
import org.songkun.enums.Sex;
import org.songkun.mapper.UsersMapper;
import org.songkun.pojo.Users;
import org.songkun.pojo.bo.UsersBo;
import org.songkun.service.UsersService;
import org.songkun.utils.DateUtil;
import org.songkun.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;

@Service
public class UsersServiceImpl implements UsersService {

    private static final String FACE_URL = "http://122.152.205.72:88/group1/M00/00/05/CpoxxFw_8_qAIlFXAAAcIhVPdSg994.png";

    @Autowired
    private UsersMapper usersMapper;

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public boolean isUsersExists(String username) {
        Example example = new Example(Users.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("username", username);
        Users users = usersMapper.selectOneByExample(example);
        return users != null ? true : false;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Users registUsers(UsersBo usersBo) {
        Users users = new Users();
        users.setId(Sid.next());
        users.setUsername(usersBo.getUsername());
        try {
            users.setPassword(MD5Utils.getMD5Str(usersBo.getPassword()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        users.setNickname(usersBo.getUsername());
        users.setBirthday(DateUtil.stringToDate("1990-01-01"));
        users.setFace(FACE_URL);
        users.setSex(Sex.SECRET.type);
        users.setCreatedTime(new Date());
        users.setUpdatedTime(new Date());
        int result = usersMapper.insert(users);
        if(result != 1) {
            return null;
        }
        return users;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public Users loginUsers(String username, String password) {
        Example example = new Example(Users.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("username", username);
        criteria.andEqualTo("password", password);
        return usersMapper.selectOneByExample(example);
    }

}
