package org.songkun.service.center.impl;

import com.github.pagehelper.PageHelper;
import org.songkun.mapper.CustomOrdersMapper;
import org.songkun.pojo.vo.center.CenterOrdersVo;
import org.songkun.service.BaseService;
import org.songkun.service.center.CenterOrdersService;
import org.songkun.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CenterOrdersServiceImpl extends BaseService implements CenterOrdersService{

    @Autowired
    private CustomOrdersMapper customOrdersMapper;

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult queryOrdersByOrderStatus(String userId, String orderStatus, Integer page, Integer pageSize) {
        Map<String, Object> map = new HashMap<>();
        map.put("userId", userId);
        map.put("orderStatus", orderStatus);

        PageHelper.startPage(page, pageSize);
        List<CenterOrdersVo> list = customOrdersMapper.queryOrdersByOrderStatus(map);

        return setPageInfo(list);
    }
}
