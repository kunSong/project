package org.songkun.service;

import org.songkun.pojo.Stu;

public interface StuService {

    int save();

    Stu getStudent(int id);

    int updateStudent(int id, String name);

    int deleteStudent(int id);

    void saveParent();

    void saveChild();

    void testTransactional();

}
