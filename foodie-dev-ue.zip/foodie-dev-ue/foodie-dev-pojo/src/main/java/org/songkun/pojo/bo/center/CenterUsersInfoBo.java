package org.songkun.pojo.bo.center;

import org.hibernate.validator.constraints.Length;

import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.Date;

public class CenterUsersInfoBo {

    @NotBlank
    @Length(max = 12, message = "长度不能超过12位")
    /**
     * 昵称 昵称
     */
    private String nickname;

    @NotBlank
    @Length(max = 12, message = "长度不能超过12位")
    /**
     * 真实姓名 真实姓名
     */
    private String realname;

    @Pattern(regexp = "^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17[013678])|(18[0,5-9]))\\d{8}$", message = "手机号格式不正确")
    /**
     * 手机号 手机号
     */
    private String mobile;

    @Email
    /**
     * 邮箱地址 邮箱地址
     */
    private String email;

    @Min(value = 0, message = "选择正确的性别")
    @Max(value = 2, message = "选择正确的性别")
    /**
     * 性别 性别 1:男  0:女  2:保密
     */
    private Integer sex;

    @Past(message = "请选过去的时间")
    /**
     * 生日 生日
     */
    private Date birthday;

    /**
     * 头像 头像
     */
    private String face;

    public String getFace() {
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }
}
