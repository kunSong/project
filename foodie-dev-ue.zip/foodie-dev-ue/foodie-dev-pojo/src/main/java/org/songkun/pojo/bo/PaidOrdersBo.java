package org.songkun.pojo.bo;

public class PaidOrdersBo {

    private String mchOrderId;

    public String getMchOrderId() {
        return mchOrderId;
    }

    public void setMchOrderId(String mchOrderId) {
        this.mchOrderId = mchOrderId;
    }
}
