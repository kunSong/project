package org.songkun.pojo;

import javax.persistence.Id;

public class Stu {
    /**
     * 学号 学号
     */
    @Id
    private Integer id;

    /**
     * 姓名 姓名
     */
    private String name;

    /**
     * 年龄 年龄
     */
    private Integer age;

    /**
     * 获取学号 学号
     *
     * @return id - 学号 学号
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置学号 学号
     *
     * @param id 学号 学号
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取姓名 姓名
     *
     * @return name - 姓名 姓名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置姓名 姓名
     *
     * @param name 姓名 姓名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取年龄 年龄
     *
     * @return age - 年龄 年龄
     */
    public Integer getAge() {
        return age;
    }

    /**
     * 设置年龄 年龄
     *
     * @param age 年龄 年龄
     */
    public void setAge(Integer age) {
        this.age = age;
    }
}