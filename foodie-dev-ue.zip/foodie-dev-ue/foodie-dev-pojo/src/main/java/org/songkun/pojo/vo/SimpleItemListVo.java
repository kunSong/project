package org.songkun.pojo.vo;

import java.util.Date;

public class SimpleItemListVo {

    private String itemId;
    private String itemName;
    private String itemImageUrl;
    private Date itemCreatedTime;

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemImageUrl() {
        return itemImageUrl;
    }

    public void setItemImageUrl(String itemImageUrl) {
        this.itemImageUrl = itemImageUrl;
    }

    public Date getItemCreatedTime() {
        return itemCreatedTime;
    }

    public void setItemCreatedTime(Date itemCreatedTime) {
        this.itemCreatedTime = itemCreatedTime;
    }
}
