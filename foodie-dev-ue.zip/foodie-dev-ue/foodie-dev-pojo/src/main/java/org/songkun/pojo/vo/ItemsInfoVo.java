package org.songkun.pojo.vo;

import org.songkun.pojo.Items;
import org.songkun.pojo.ItemsImg;
import org.songkun.pojo.ItemsParam;
import org.songkun.pojo.ItemsSpec;

import java.util.List;

public class ItemsInfoVo {

    public Items item;
    public ItemsParam itemParams;
    public List<ItemsImg> itemImgList;
    public List<ItemsSpec> itemSpecList;

    public Items getItem() {
        return item;
    }

    public void setItem(Items item) {
        this.item = item;
    }

    public ItemsParam getItemParams() {
        return itemParams;
    }

    public void setItemParams(ItemsParam itemParams) {
        this.itemParams = itemParams;
    }

    public List<ItemsImg> getItemImgList() {
        return itemImgList;
    }

    public void setItemImgList(List<ItemsImg> itemImgList) {
        this.itemImgList = itemImgList;
    }

    public List<ItemsSpec> getItemSpecList() {
        return itemSpecList;
    }

    public void setItemSpecList(List<ItemsSpec> itemSpecList) {
        this.itemSpecList = itemSpecList;
    }
}
