package org.songkun.enums;

public enum Sex {

    MAN(1, "男"),
    WOMEN(2, "女"),
    SECRET(0, "保密");

    public Integer type;
    public String value;

    Sex(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
