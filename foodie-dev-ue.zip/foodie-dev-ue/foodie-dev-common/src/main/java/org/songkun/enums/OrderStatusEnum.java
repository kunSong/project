package org.songkun.enums;

public enum OrderStatusEnum {

    WAITING(10, "待付款"),
    PAID(20, "已付款，待发货"),
    SENT(30, "已发货，待收货"),
    COMPLETED(40, "交易完成"),
    CLOSED(50, "交易关闭");


    public Integer type;
    public String value;

    OrderStatusEnum(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
