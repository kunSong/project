package org.songkun.enums;

public enum ItemCategory {

    TOP_CATEGORY(1, "一级分类"),
    SECOND_CATEGORY(2, "二级分类"),
    THIRD_CATEGORY(3, "三级分类");

    public Integer type;
    public String value;

    ItemCategory(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
