package org.songkun.enums;

public enum  YesOrNo {

    YES(1, "是"),
    NO(0, "否");

    public Integer type;
    public String value;

    YesOrNo(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
