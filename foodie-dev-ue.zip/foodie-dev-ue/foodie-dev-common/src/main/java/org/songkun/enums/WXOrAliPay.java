package org.songkun.enums;

public enum WXOrAliPay {

    WX(1, "微信"),
    ALI(2, "支付宝");

    public Integer type;
    public String value;

    WXOrAliPay(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
